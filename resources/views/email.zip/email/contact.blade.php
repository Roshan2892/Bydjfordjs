Hi, {{ $name }} sent you a mail from bydjfordjs.in

{{ $msg }}